import 'dart:convert';

import 'package:shelf/shelf.dart';
import 'package:shelf_router/shelf_router.dart';

import 'package:jualbeli_backend/repositories/order_repository.dart';

class OrderRoutes {
  OrderRoutes._();

  static final OrderRoutes instance =
      OrderRoutes._();

  final OrderRepository _repository =
      OrderRepository.instance;

  Router get router {
    final router = Router();

    router.post(
      '/',
      _createOrder,
    );

    return router;
  }

  Future<Response> _createOrder(
    Request request,
  ) async {
    try {
      final body =
          await request.readAsString();

      final data =
          jsonDecode(body);

      if (data is! Map<String, dynamic>) {
        return Response(
          400,
          body: jsonEncode({
            'error': 'Invalid request body.',
          }),
          headers: {
            'Content-Type':
                'application/json',
          },
        );
      }

      final email = data['email'];

      if (email == null ||
          email.toString().trim().isEmpty) {
        return Response(
          400,
          body: jsonEncode({
            'error': 'Email is required.',
          }),
          headers: {
            'Content-Type':
                'application/json',
          },
        );
      }

      final orderId =
          await _repository.createOrder(
        email: email.toString(),
      );

      return Response(
        201,
        body: jsonEncode({
          'message':
              'Order created successfully.',
          'orderId': orderId,
        }),
        headers: {
          'Content-Type':
              'application/json',
        },
      );
    } catch (e) {
      print(
        'Create order error: $e',
      );

      return Response(
        500,
        body: jsonEncode({
          'error':
              'Failed to create order.',
          'details': e.toString(),
        }),
        headers: {
          'Content-Type':
              'application/json',
        },
      );
    }
  }
}