import 'dart:async';
import 'dart:io';

class BackendProcess {
  static Process? _process;

  static Future<void> start() async {
    if (!Platform.isWindows) {
      return;
    }

    if (_process != null) {
      return;
    }

    final projectDirectory = Directory.current;

    final backendDirectory = Directory(
      '${projectDirectory.path}\\jualbeli_backend',
    );

    if (!await backendDirectory.exists()) {
      throw Exception(
        'jualbeli_backend not found:\n'
        '${backendDirectory.path}',
      );
    }

    print('[Backend] Starting...');
    print('[Backend] ${backendDirectory.path}');

    _process = await Process.start(
      'dart',
      ['run'],
      workingDirectory: backendDirectory.path,
      runInShell: true,
    );

    print('[Backend] Started. PID: ${_process!.pid}');

    _process!.stdout
        .transform(SystemEncoding().decoder)
        .listen((data) {
      stdout.write('[Backend] $data');
    });

    _process!.stderr
        .transform(SystemEncoding().decoder)
        .listen((data) {
      stderr.write('[Backend ERROR] $data');
    });

    unawaited(
      _process!.exitCode.then((exitCode) {
        print('[Backend] Exited with code $exitCode');
        _process = null;
      }),
    );
  }

  static Future<void> stop() async {
    final process = _process;

    if (process == null) {
      return;
    }

    print('[Backend] Stopping...');

    await Process.run(
      'taskkill',
      [
        '/PID',
        process.pid.toString(),
        '/T',
        '/F',
      ],
      runInShell: true,
    );

    _process = null;

    print('[Backend] Stopped.');
  }
}

